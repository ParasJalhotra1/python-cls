import calendar

x= 2020
y= 12
print(calendar.month(x,y))